package Interface;
public interface Categorizable {
    String getCategory();
}