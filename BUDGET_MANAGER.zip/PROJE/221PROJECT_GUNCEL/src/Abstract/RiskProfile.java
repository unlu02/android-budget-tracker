package Abstract;
public class RiskProfile {
    private String level; // Low, Medium, High gibi değerler
    private String comments; // Risk hakkındaki açıklamalar

    public RiskProfile(String level, String comments) {
        this.level = level;
        this.comments = comments;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return
                "Level = '" + level + '\'' +
                ", Comments = '" + comments ;
    }
}
