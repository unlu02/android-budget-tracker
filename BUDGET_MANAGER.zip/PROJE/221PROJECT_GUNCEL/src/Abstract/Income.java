package Abstract;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Income extends BudgetEntry{

    private String source;

    public Income(String description, double amount, Date date, String source) {
        super(description, amount, date);
        this.source = source;
    }
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }


    @Override
    public double calculateImpact() {
        return getAmount();
    }

    @Override
    public String toString() {
        return "Type : Income\n" +
                "Description: " + getDescription() + '\n' +
                "Amount: " + getAmount() + " TL \n" +
                "Date: " + new SimpleDateFormat("dd MMMM yyyy", new Locale("en", "EN")).format(getDate()) + '\n' +
                "Source: " + getSource() + "\n\n";
    }

}

