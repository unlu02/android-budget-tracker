package Abstract;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Investment extends BudgetEntry{

    private String investmentType; // "Hisse","EuroBond"
    private String assetName;    // TUPRS(Tüpraş)
    private double expectedReturn; // Beklenen Getiri
    private RiskProfile riskProfile;

    public Investment(String description, double amount, Date date,
                      String investmentType, String assetName, double expectedReturn,RiskProfile riskProfile) {
        super(description, amount, date);
        this.investmentType = investmentType;
        this.assetName = assetName;
        this.expectedReturn = expectedReturn;
        this.riskProfile = riskProfile;
    }

    public String getInvestmentType() {
        return investmentType;
    }

    public void setInvestmentType(String investmentType) {
        this.investmentType = investmentType;
    }

    public String getAssetName() {
        return assetName;
    }

    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }

    public double getExpectedReturn() {
        return expectedReturn;
    }

    public void setExpectedReturn(double expectedReturn) {
        this.expectedReturn = expectedReturn;
    }

    public RiskProfile getRiskProfile() {
        return riskProfile;
    }

    public void setRiskProfile(RiskProfile riskProfile) {
        this.riskProfile = riskProfile;
    }



    @Override
    public double calculateImpact() {
        return 0;
    }

    
    @Override
    public String toString() {
        return "Type : Investment\n" +
                "Description: " + getDescription() + '\n' +
                "Amount: " + getAmount() + " TL \n" +
                "Date: " + new SimpleDateFormat("dd MMMM yyyy", new Locale("en", "EN")).format(getDate()) + '\n' + 
                "Investment Type: " + investmentType + '\n' +
                "Asset Name: " + assetName + '\n' +
                "Expected Return: " + expectedReturn + '\n' +
                "Risk Profile: " + riskProfile + "\n\n"; // Risk profil bilgisi de burada görüntülenecek
    }
}
