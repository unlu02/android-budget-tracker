package Abstract;

import Interface.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Expense extends BudgetEntry implements Categorizable{

    private String category;


    public Expense(String description, double amount, Date date, String category) {
        super(description, amount, date);
        this.category = category;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public double calculateImpact() {
        return -getAmount();
    }

    @Override
    public String toString() {
        return "Type: Expense\n" +
                "Description: " + getDescription() + '\n' +
                "Amount: " + getAmount() + " TL \n" +
                "Date: " + new SimpleDateFormat("dd MMMM yyyy", new Locale("en", "EN")).format(getDate()) + '\n' +
                "Category: " + category + "\n\n";
    }
}
