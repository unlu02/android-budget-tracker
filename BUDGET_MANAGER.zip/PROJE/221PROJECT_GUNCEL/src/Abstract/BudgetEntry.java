package Abstract;
import java.util.Date;

public abstract class BudgetEntry {
    protected String description;
    protected double amount;
    protected Date date;
    protected static int totalEntries = 0;
    

    public BudgetEntry( String description, double amount, Date date) {
        this.description = description;
        this.amount = amount;
        this.date = date;
        incrementTotalEntries();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public static int getTotalEntries() {
        return totalEntries;
    }

    public static void incrementTotalEntries() {
        totalEntries++;
    }

    public abstract double calculateImpact();

}
