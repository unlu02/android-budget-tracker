package Main;
import Abstract.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class BudgetEntrySys {
    private static List<BudgetEntry> entries = new ArrayList<>();
    private static Set<String> categories = new HashSet<>();
    private static SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    private static String mainJSONFile = "main.json";

    
    
    public static String addBudgetEntry(BudgetEntry entry) {
    	String output = "";
        for (BudgetEntry existingEntry : entries) {
            if (existingEntry.getDescription().equalsIgnoreCase(entry.getDescription())) {
            	output += "There is already budget entry with that description and date. It is not added.";
                return output;
            }
        }

        entries.add(entry);
        saveAllEntriesToJSONFile(BudgetEntrySys.getMainJSONFile());
        output = entry.getClass().getSimpleName() + " entry added.";

        if (entry instanceof Expense) {
            categories.add(((Expense) entry).getCategory().toLowerCase());
        }
        
        return output;
    }

    
    public static BudgetEntry searchEntry(String description) {
        for (BudgetEntry entry : entries) {
            if (entry.getDescription().equalsIgnoreCase(description)) {
                return entry;
            }
        }
        return null;
    }

    public static boolean deleteEntry(String description) {

        BudgetEntry entry = searchEntry(description);
        if (entry != null) {
            entries.remove(entry);
            String saveResult = saveAllEntriesToJSONFile(BudgetEntrySys.getMainJSONFile());
            return true;
        }
        return false;
    }


    public static String displayEntries() {
    	String output = "";
    	
    	for(BudgetEntry entry : entries) {
    		output += entry;
    	}
    	return output;
    }

    public static double calculateTotalBalance() {
        double total = 0;
        for (BudgetEntry entry : entries) {
            total += entry.calculateImpact();
        }
        return total;
    }

    public static String displayCategories() {
        if (categories.isEmpty()) {
            return "No categories added yet.";
        }
        return "Categories: " + categories;
    }

    public static String generateCategoryReport() {
    	String report = "";
        Map<String, Double> categoryTotals = new HashMap<>();

        for (BudgetEntry entry : entries) {
            if (entry instanceof Expense) {
                Expense expense = (Expense) entry;
                String category = expense.getCategory();
                categoryTotals.put(category,
                        categoryTotals.getOrDefault(category, 0.0) + expense.getAmount());
            }
        }

        if (categoryTotals.isEmpty()) {
        	report +=  "No expense entries to generate report.";
            
        } else {
        	report += "--- Category Report ---\n";
            for (Map.Entry<String, Double> entry : categoryTotals.entrySet()) {
                report += entry.getKey() + ": " + entry.getValue() + "\n";
            }
        }
        
        return report;
    }

    public static int getEntryCount(){
        return BudgetEntry.getTotalEntries();
    }
    
    public static String readFromJSONFile(String fileName) {
        try {
        	
        	String output = "";
            // JSON dosyasını oku
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);
            StringBuilder jsonContent = new StringBuilder();
            
            while (scanner.hasNextLine()) {
                jsonContent.append(scanner.nextLine());
            }
            scanner.close();
            
            JSONObject jsonObject = new JSONObject(jsonContent.toString());
            JSONArray entriesArray = jsonObject.getJSONArray("entries");
            
            for (int i = 0; i < entriesArray.length(); i++) {
                JSONObject entryObject = entriesArray.getJSONObject(i);
                String type = entryObject.getString("type");
                String description = entryObject.getString("description");
                double amount = entryObject.getDouble("amount");
                Date date = sdf.parse(entryObject.getString("date"));
                
                BudgetEntry entry = null;
                
                switch (type) {
                    case "Income":
                        String source = entryObject.getString("source");
                        entry = new Income(description, amount, date, source);
                        break;
                        
                    case "Expense":
                        String category = entryObject.getString("category");
                        entry = new Expense(description, amount, date, category);
                        break;
                        
                    case "Investment":
                        String investmentType = entryObject.getString("investmentType");
                        String assetName = entryObject.getString("assetName");
                        double expectedReturn = entryObject.getDouble("expectedReturn");
                        
                        JSONObject riskObject = entryObject.getJSONObject("riskProfile");
                        String riskLevel = riskObject.getString("level");
                        String riskComments = riskObject.getString("comments");
                        
                        RiskProfile riskProfile = new RiskProfile(riskLevel, riskComments);
                        entry = new Investment(description, amount, date, 
                                              investmentType, assetName, expectedReturn, riskProfile);
                        break;
                }
                
                output += entry.toString() + "\n";
                
                if (entry != null) {
                    addBudgetEntry(entry);
                }
            }
            
            return output;
        } catch (FileNotFoundException e) {
            return "Dosya bulunamadı: " + fileName;
        } catch (Exception e) {
            return "JSON dosyası okunurken hata oldu : " + e.getMessage() ;
        }
    }
    
    public static String saveAllEntriesToJSONFile(String fileName) {
        try {
            
            JSONObject jsonObject = new JSONObject();
            JSONArray entriesArray = new JSONArray();
            
            for (BudgetEntry entry : entries) {
                JSONObject entryObject = new JSONObject();
                entryObject.put("type", entry.getClass().getSimpleName());
                entryObject.put("description", entry.getDescription());
                entryObject.put("amount", entry.getAmount());
                entryObject.put("date", sdf.format(entry.getDate()));
                
               
                if (entry instanceof Income) {
                    Income income = (Income) entry;
                    entryObject.put("source", income.getSource());
                } else if (entry instanceof Expense) {
                    Expense expense = (Expense) entry;
                    entryObject.put("category", expense.getCategory());
                } else if (entry instanceof Investment) {
                    Investment investment = (Investment) entry;
                    entryObject.put("investmentType", investment.getInvestmentType());
                    entryObject.put("assetName", investment.getAssetName());
                    entryObject.put("expectedReturn", investment.getExpectedReturn());
                    
                    // Risk profili ekle
                    JSONObject riskObject = new JSONObject();
                    RiskProfile risk = investment.getRiskProfile();
                    riskObject.put("level", risk.getLevel());
                    riskObject.put("comments", risk.getComments());
                    entryObject.put("riskProfile", riskObject);
                }
                
                entriesArray.put(entryObject);
            }
            
            jsonObject.put("entries", entriesArray);
            
            
            java.io.FileWriter fileWriter = new java.io.FileWriter(fileName);
            fileWriter.write(jsonObject.toString(2));
            fileWriter.close();
            
            return "Tüm kayıtlar başarıyla kaydedildi: " + fileName;
        } catch (Exception e) {
            return "JSON dosyasına kaydederken hata: " + e.getMessage();
        }
    }
    
    public static String getMainJSONFile() {
    	return mainJSONFile;
    }

}

