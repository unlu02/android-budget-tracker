package Main;

import java.awt.EventQueue;

import GUI.MainFrame;

public class BudgetEntryMain {
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BudgetEntrySys.readFromJSONFile(BudgetEntrySys.getMainJSONFile());
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
