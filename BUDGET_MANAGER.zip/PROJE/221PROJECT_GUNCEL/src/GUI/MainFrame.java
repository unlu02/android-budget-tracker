package GUI;

import Abstract.*;
import Main.BudgetEntrySys;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainFrame extends JFrame {
    private JPanel contentPane;
    private JComboBox<String> entryTypeBox;
    private JTextField descField, amountField, dateField;
    private JTextArea displayArea;
    SearchFrame sf = new SearchFrame();
   


    public MainFrame() {
        setTitle("Budget Entry System GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 750, 550);
        contentPane = new JPanel();
        contentPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblType = new JLabel("Type:");
        lblType.setBounds(10, 34, 100, 20);
        contentPane.add(lblType);

        entryTypeBox = new JComboBox<>();
        entryTypeBox.setBounds(120, 33, 150, 22);
        entryTypeBox.setModel(new DefaultComboBoxModel<>(new String[] {"Income", "Expense", "Investment"}));
        contentPane.add(entryTypeBox);

        JLabel lblDesc = new JLabel("Description:");
        lblDesc.setBounds(10, 65, 100, 20);
        contentPane.add(lblDesc);

        descField = new JTextField();
        descField.setBounds(120, 63, 150, 22);
        contentPane.add(descField);

        JLabel lblAmount = new JLabel("Amount:");
        lblAmount.setBounds(10, 96, 100, 20);
        contentPane.add(lblAmount);

        amountField = new JTextField();
        amountField.setBounds(120, 95, 150, 22);
        contentPane.add(amountField);


        JLabel lblDate = new JLabel("Date (dd-MM-yyyy):");
        lblDate.setBounds(10, 127, 110, 20);
        contentPane.add(lblDate);

        dateField = new JTextField();
        dateField.setBounds(120, 126, 150, 22);
        contentPane.add(dateField);

        JButton btnAdd = new JButton("Add Entry");
        btnAdd.setBounds(362, 32, 150, 25);
        contentPane.add(btnAdd);

        JButton btnDelete = new JButton("Delete Entry");
        btnDelete.setBounds(362, 63, 150, 25);
        contentPane.add(btnDelete);

        JButton btnSearch = new JButton("Search Entry");
        btnSearch.setBounds(362, 94, 150, 25);
        contentPane.add(btnSearch);

        JButton btnDisplay = new JButton("Display All");
        btnDisplay.setBounds(362, 125, 150, 25);
        contentPane.add(btnDisplay);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 200, 700, 280);
        contentPane.add(scrollPane);

        displayArea = new JTextArea();
        scrollPane.setViewportView(displayArea);
        displayArea.setEditable(false);

        JButton btnGenerateCategoryReport = new JButton("Generate Category Report");
        btnGenerateCategoryReport.setBounds(522, 33, 188, 25);
        contentPane.add(btnGenerateCategoryReport);
        
        JButton btnDisplayCategories = new JButton("Display Categories");
        btnDisplayCategories.setBounds(522, 64, 188, 25);
        contentPane.add(btnDisplayCategories);
        
        JButton btnCalculateTotalBalance = new JButton("Calculate Total Balance");
        btnCalculateTotalBalance.setBounds(522, 94, 188, 25);
        contentPane.add(btnCalculateTotalBalance);
        
        JButton btnGetEntryCount = new JButton("Get Entry Count");
        btnGetEntryCount.setBounds(522, 126, 188, 25);
        contentPane.add(btnGetEntryCount);
        
        btnAdd.addActionListener(e -> addEntry());
        KeyAdapter enterKeyListener = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    addEntry();
                }
            }
        };

        descField.addKeyListener(enterKeyListener);
        amountField.addKeyListener(enterKeyListener);
        dateField.addKeyListener(enterKeyListener);


        btnDelete.addActionListener(e -> {
        	 DeleteFrame deleteFrame = new DeleteFrame();
        	 deleteFrame.setVisible(true);
            
        });

        btnSearch.addActionListener(e -> {
        	sf.setVisible(true);
        });

        btnDisplay.addActionListener(e -> {
            displayArea.setText(BudgetEntrySys.displayEntries());
            resetFields();
        });
        
        btnGenerateCategoryReport.addActionListener(e -> {
            displayArea.setText(BudgetEntrySys.generateCategoryReport());
            resetFields();
        });
        
        btnDisplayCategories.addActionListener(e -> {
            displayArea.setText(BudgetEntrySys.displayCategories());
         
            resetFields();
        });
        
        btnCalculateTotalBalance.addActionListener(e -> {
            displayArea.setText("Total Balance: " + BudgetEntrySys.calculateTotalBalance() + " TL");
   
            resetFields();
        });
        
        btnGetEntryCount.addActionListener(e -> {
            displayArea.setText("Entry Count: " + BudgetEntrySys.getEntryCount());
 
            resetFields();
        });
        
    }
    
    private void resetFields() {
        entryTypeBox.setSelectedIndex(0);
        descField.setText("");
        amountField.setText("");
        dateField.setText("");

    }
    
    private void addEntry() {
        String output = "";
        String type = (String) entryTypeBox.getSelectedItem();
        String desc = descField.getText();
        double amount;
        Date date;
        try {
            amount = Double.parseDouble(amountField.getText());
            date = new SimpleDateFormat("dd-MM-yyyy").parse(dateField.getText());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Invalid amount or date format.");
            return;
        }
        
        BudgetEntry entry = null;
        switch (type) {
            case "Income":
                String source = JOptionPane.showInputDialog("Source:");
                entry = new Income(desc, amount, date, source);
                break;
            case "Expense":
                String category = JOptionPane.showInputDialog("Category:");
                entry = new Expense(desc, amount, date, category);
                break;
            case "Investment":
                String investType = JOptionPane.showInputDialog("Investment Type (E.g. EuroBond TR47843...):");
                String asset = JOptionPane.showInputDialog("Asset (TR4783...):");

                String expectedReturnStr = JOptionPane.showInputDialog("Expected Return (E.g. 0.04):");
                double expectedReturn = 0.0;
                try {
                    expectedReturn = Double.parseDouble(expectedReturnStr);
                } catch (Exception ignored) {
                    JOptionPane.showMessageDialog(null, "Invalid Expected Return format.");
                    return;
                }

                if (expectedReturn < 0) {
                    JOptionPane.showMessageDialog(null, "Expected Return cannot be negative.");
                    return;
                }

                String riskLevel = JOptionPane.showInputDialog("Risk Level (E.g. LOW, MEDIUM, HIGH):");
                String riskComment = JOptionPane.showInputDialog("Risk Comment:");

                RiskProfile risk = new RiskProfile(riskLevel, riskComment);
                entry = new Investment(desc, amount, date, investType, asset, expectedReturn, risk);
                break;
        }

        output = BudgetEntrySys.addBudgetEntry(entry);
        displayArea.setText(output);
        resetFields();
    }
}
