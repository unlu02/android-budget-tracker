package GUI;

import Abstract.BudgetEntry;
import Main.BudgetEntrySys;
import Abstract.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchFrame extends JFrame {
    private JTextField searchField;
    private JTextArea resultArea;
    
    
    public SearchFrame() {
    	
        setTitle("Search Entry");
        setSize(400, 300);
        setLocationRelativeTo(null); // Ortalar
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Sadece bu frame kapanır

        JPanel panel = new JPanel();
        panel.setLayout(null);
        setContentPane(panel);

        JLabel lblDesc = new JLabel("Description:");
        lblDesc.setBounds(20, 20, 100, 25);
        panel.add(lblDesc);

        searchField = new JTextField();
        searchField.setBounds(120, 20, 200, 25);
        panel.add(searchField);

        JButton btnSearch = new JButton("Search");
        btnSearch.addActionListener(null);
        btnSearch.setBounds(120, 60, 100, 30);
        panel.add(btnSearch);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 110, 340, 130);
        panel.add(scrollPane);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        scrollPane.setViewportView(resultArea);

        // Buton olayını tanımla
        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String desc = searchField.getText();
                BudgetEntry found = BudgetEntrySys.searchEntry(desc);
                resultArea.setText(found != null ? found.toString() : "No matching entry found.");
            }
        });
    }
}

