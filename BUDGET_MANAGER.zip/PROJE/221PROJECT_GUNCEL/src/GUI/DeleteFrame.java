package GUI;

import javax.swing.*;

import Main.BudgetEntrySys;

public class DeleteFrame extends JFrame {
    private JTextField descField;
    private JTextArea resultArea;

    public DeleteFrame() {
        setTitle("Delete Entry");
        setSize(400, 250);
        setLocationRelativeTo(null); // Ortalar
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Sadece bu pencere kapanır

        JPanel panel = new JPanel();
        panel.setLayout(null);
        setContentPane(panel);

        JLabel lblDesc = new JLabel("Description to Delete:");
        lblDesc.setBounds(20, 20, 150, 25);
        panel.add(lblDesc);

        descField = new JTextField();
        descField.setBounds(170, 20, 180, 25);
        panel.add(descField);

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBounds(140, 60, 100, 30);
        panel.add(btnDelete);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 110, 330, 80);
        panel.add(scrollPane);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        scrollPane.setViewportView(resultArea);

        btnDelete.addActionListener(e -> {
            String desc = descField.getText();
            boolean deleted = BudgetEntrySys.deleteEntry(desc);
            resultArea.setText(deleted ? "✅ Entry deleted successfully." : "❌ Entry not found.");
           
        });
    }
}

